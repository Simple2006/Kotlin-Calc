
rootProject.name = "KotlinCalc"

